package com.dev.store.controller;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.Medicine;
import com.dev.store.repositories.MedicineRepositories;

@Controller
public class MedicineController {

	private static String pathImages = "C:\\Users\\Wanessa_Wazmuth\\Documents\\Imagens";

	@Autowired
	private MedicineRepositories medicineRepositories;

	@GetMapping("/api/admin/medicine/toregister")
	public ModelAndView register(Medicine medicine) {
		ModelAndView mv = new ModelAndView("api/admin/medicine/register");
		mv.addObject("medicine", medicine);
		return mv;
	}

	@GetMapping("/api/admin/medicine/tolist")
	public ModelAndView list() {
		ModelAndView mv = new ModelAndView("api/admin/medicine/list");
		mv.addObject("listMedicine", medicineRepositories.findAll());
		return mv;
	}

	@GetMapping("/api/admin/medicine/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		Optional<Medicine> medicine = medicineRepositories.findById(id);
		return register(medicine.get());
	}

	@GetMapping("/api/admin/medicine/remove/{id}")
	public ModelAndView remove(@PathVariable("id") Long id) {
		
		Optional<Medicine> medicine = medicineRepositories.findById(id);
		medicineRepositories.delete(medicine.get());
		return list();
	
		
	} 
	
	


	@PostMapping("/api/admin/medicine/save")
	public ModelAndView save(@Valid Medicine medicine, BindingResult result,
			@RequestParam("file") MultipartFile file) {

		if (result.hasErrors()) {
			return register(medicine);
		}

		medicineRepositories.saveAndFlush(medicine);

		try {
			if (!file.isEmpty()) {
				byte[] bytes = file.getBytes();
				Path path = Paths
						.get(pathImages + String.valueOf(medicine.getId()) + file.getOriginalFilename());
				Files.write(path, bytes);

				medicine.setImageName(String.valueOf(medicine.getId()) + file.getOriginalFilename());
				medicineRepositories.saveAndFlush(medicine);
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return register(new Medicine());
	}
	
	
	@GetMapping("/api/search")
	public ModelAndView findByName (@RequestParam("name") String name){
		ModelAndView mv = new ModelAndView("api/searchLayout");
		mv.addObject("findByName", medicineRepositories.findByName(name));
		return mv;
    }
	
	@GetMapping("/api/searchuses")
	public ModelAndView findByUses (@RequestParam("uses") String uses){
		ModelAndView mv = new ModelAndView("api/searchLayoutUses");
		mv.addObject("findByUses", medicineRepositories.findByUses(uses));
		return mv;
    }
		

}
