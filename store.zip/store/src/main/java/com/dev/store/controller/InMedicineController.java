package com.dev.store.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.InItem;
import com.dev.store.models.InMedicine;
import com.dev.store.models.Medicine;
import com.dev.store.repositories.AdministratorRepositories;
import com.dev.store.repositories.InItemRepositories;
import com.dev.store.repositories.InMedicineRepositories;
import com.dev.store.repositories.MedicineRepositories;

@Controller
public class InMedicineController {

	private List<InItem> listIn = new ArrayList<InItem>();

	@Autowired
	private InMedicineRepositories inMedicineRepositories;

	@Autowired
	private InItemRepositories inItemRepositories;

	@Autowired
	private AdministratorRepositories administratorRepositories;

	@Autowired
	private MedicineRepositories medicineRepositories;

	@GetMapping("/api/admin/in/toregister")
	public ModelAndView register(InMedicine in, InItem inItem) {
		ModelAndView mv = new ModelAndView("/api/admin/in/register");
		mv.addObject("in", in);
		mv.addObject("listIn", this.listIn);
		mv.addObject("inItem", inItem);
		mv.addObject("listAdministrator", administratorRepositories.findAll());
		mv.addObject("listMedicine", medicineRepositories.findAll());
		return mv;
	}

	@PostMapping("/api/admin/in/save")
	public ModelAndView save(String action, InMedicine in, InItem inItem) {

		if (action.equals("item")) {
			this.listIn.add(inItem);
		} else if (action.equals("save")) {
			inMedicineRepositories.saveAndFlush(in);
			for (InItem it : listIn) {
				it.setInMedicine(in);
				inItemRepositories.saveAndFlush(it);
				Optional<Medicine> med = medicineRepositories.findById(it.getMedicine().getId());
				Medicine medicine = med.get();
				medicine.setQuantity(medicine.getQuantity() + it.getQuantity());
				medicine.setPrice(it.getDiscountValue());
				medicine.setExpireDate(it.getExpireDate());
				medicine.setCompanyName(it.getCompanyName());
				medicineRepositories.saveAndFlush(medicine);
				this.listIn = new ArrayList<>();
			}
			return register(new InMedicine(), new InItem());
		}

		return register(in, new InItem());
	}

}
