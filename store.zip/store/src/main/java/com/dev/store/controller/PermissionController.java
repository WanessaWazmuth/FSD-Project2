package com.dev.store.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.Permission;
import com.dev.store.repositories.AdministratorRepositories;
import com.dev.store.repositories.PermissionRepositories;
import com.dev.store.repositories.RoleRepositories;

@Controller
public class PermissionController {
	
	@Autowired
	private PermissionRepositories permissionRepositories;
	
	@Autowired
	private AdministratorRepositories administratorRepositories;
	
	@Autowired
	private RoleRepositories roleRepositories;
	
	
	@GetMapping("/api/admin/permission/toregister")
	public ModelAndView register(Permission permission) {
		ModelAndView mv =  new ModelAndView("api/admin/permission/register");
		mv.addObject("permission",permission);
		mv.addObject("listAdministrator",administratorRepositories.findAll());
		mv.addObject("listRole", roleRepositories.findAll());
		return mv;
	}
	
	@GetMapping("/api/admin/permission/tolist")
	public ModelAndView list() {
		ModelAndView mv=new ModelAndView("api/admin/permission/list");
		mv.addObject("listPermission", permissionRepositories.findAll());
		return mv;
	}
	
	
	@GetMapping("/api/admin/permission/remove/{id}")
	public ModelAndView remove(@PathVariable("id") Long id) {
		Optional<Permission> permission = permissionRepositories.findById(id);
		permissionRepositories.delete(permission.get());
		return list();
	}
	
	@PostMapping("/api/admin/permission/save")
	public ModelAndView save(@Valid Permission permission, BindingResult result) {
		
		if(result.hasErrors()) {
			return register(permission);
		}
		permissionRepositories.saveAndFlush(permission);
		
		return register(new Permission());
	}

}
