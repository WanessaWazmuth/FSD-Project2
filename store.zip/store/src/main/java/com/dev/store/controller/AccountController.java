package com.dev.store.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.Account;
import com.dev.store.models.Client;
import com.dev.store.repositories.AccountRepositories;
import com.dev.store.repositories.ClientRepositories;

@Controller
public class AccountController {
	
	private Account account;
	
	@Autowired
	private AccountRepositories accountRepositories;
	
	@Autowired
	private ClientRepositories clientRepositorio;
	
	
	@GetMapping("/api/user/account")
	public ModelAndView register(Account account) {
		ModelAndView mv =  new ModelAndView("api/user/account");
		mv.addObject("account", account);
		mv.addObject("listClient", clientRepositorio.findAll());
		return mv;
	}
	


	@PostMapping("/api/user/saveaccount")
	public ModelAndView save(@Valid Account account) {
		
			Optional<Client> med = clientRepositorio.findById(account.getClient().getId());
			Client client = med.get();
			if(client.getId().equals(account.getClient().getId()) ) {
			client.setFunds(client.getFunds() + account.getFound());
			clientRepositorio.saveAndFlush(client);
			accountRepositories.saveAndFlush(account);
			
		}
		
		
		return register(new Account());
	}
	

	@GetMapping("/api/user/tolistaccount")
	public ModelAndView list() {
		ModelAndView mv=new ModelAndView("api/user/tolistaccount");
		mv.addObject("listAccount", accountRepositories.findAll());
		return mv;
	}

}
