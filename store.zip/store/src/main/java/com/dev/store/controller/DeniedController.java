package com.dev.store.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DeniedController {
	

	@GetMapping("/api/deniedAdministrative")
	public ModelAndView deniedAdministrative() {
		ModelAndView mv =  new ModelAndView("/api/deniedAdministrative");
		
		return mv;
	}
	
	@GetMapping("/api/deniedClient")
	public ModelAndView deniedClient() {
		ModelAndView mv =  new ModelAndView("/api/deniedClient");
		
		return mv;
	}
	
	

}
