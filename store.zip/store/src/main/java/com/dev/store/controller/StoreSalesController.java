package com.dev.store.controller;

import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dev.store.models.Buy;
import com.dev.store.repositories.BuyRepositories;
import com.dev.store.service.ReportServiceSales;
import net.sf.jasperreports.engine.JRException;

@SpringBootApplication
@RestController
public class StoreSalesController {
	
	@Autowired
	private BuyRepositories buyRepositories;
	
	@Autowired
	private ReportServiceSales service;
	
	@GetMapping("/api/admin/getSales")
	public List<Buy> getSales(){
		return buyRepositories.findAll();
	}

	@GetMapping("/api/admin/buy/{format}")
	public String generateReport(@PathVariable String format)  throws FileNotFoundException, JRException{
		return service.exportReport(format);
	}
	


}
