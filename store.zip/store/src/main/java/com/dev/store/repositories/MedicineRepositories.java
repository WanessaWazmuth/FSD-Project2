package com.dev.store.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.dev.store.models.Medicine;

public interface MedicineRepositories extends JpaRepository<Medicine, Long>  {

	 List<Medicine> findByName (String name);
	 List<Medicine> findByUses (String uses);

}

 